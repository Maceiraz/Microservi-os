package br.com.escola.produtos;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {
    private final List<Produto> produtos = List.of(
        new Produto(1, "Teclado", 89.90),
        new Produto(2, "Mouse", 49.90),
        new Produto(3, "Monitor", 799.90)
    );

    @GetMapping
    public List<Produto> listar() {
        return produtos;
    }

    @GetMapping("/{id}")
    public Produto buscar(@PathVariable int id) {
        return produtos.stream()
            .filter(produto -> produto.id() == id)
            .findFirst()
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Produto não encontrado"));
    }

    public record Produto(int id, String nome, double preco) {}
}

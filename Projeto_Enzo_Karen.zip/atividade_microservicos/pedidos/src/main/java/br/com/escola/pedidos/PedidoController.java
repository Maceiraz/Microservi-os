package br.com.escola.pedidos;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {
    private final List<Pedido> pedidos = List.of(
        new Pedido(100, 1, 2, "CONFIRMADO"),
        new Pedido(101, 2, 1, "PAGO"),
        new Pedido(102, 3, 1, "EM_PROCESSAMENTO")
    );

    @GetMapping
    public List<Pedido> listar() {
        return pedidos;
    }

    @GetMapping("/{id}")
    public Pedido buscar(@PathVariable int id) {
        return pedidos.stream()
            .filter(pedido -> pedido.id() == id)
            .findFirst()
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado"));
    }

    public record Pedido(int id, int produtoId, int quantidade, String status) {}
}

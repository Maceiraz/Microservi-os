package br.com.escola.entregas;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.http.MediaType;

@SpringBootTest
@AutoConfigureMockMvc
class EntregaControllerTest {
    @Autowired
    MockMvc mvc;

    @Test
    void entregaInexistenteDeveRetornar404() throws Exception {
        mvc.perform(get("/entregas/999"))
            .andExpect(status().isNotFound());
    }

    @Test
    void listaEntregasDeveResponder200() throws Exception {
        mvc.perform(get("/entregas"))
            .andExpect(status().isOk());
    }

    @Test
    void produtoInexistenteDeveImpedirCriacaoDaEntrega() throws Exception {
        mvc.perform(post("/entregas")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"pedidoId\":100,\"produtoId\":999,\"endereco\":\"Rua Exemplo, 10\"}"))
            .andExpect(status().isBadRequest());
    }
}
